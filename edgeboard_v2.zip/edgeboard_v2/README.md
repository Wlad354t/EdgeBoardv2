# EdgeBoard v2: statistically tested spread model

Sport-agnostic point-spread model trained and backtested on real data
(NFL built in from nflverse, 1999 to now, with closing lines and odds).
Any other sport works by uploading a CSV.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py              # the app
python run_backtest.py            # same pipeline in the terminal
python run_backtest.py --refresh  # pull the latest scores + lines first
```

## Tabs

| Tab | What it answers |
|---|---|
| Verdict | Does the model know anything the closing line doesn't? (b1 t-test, ATS record with Wilson CI, binomial p-value, bootstrap ROI CI, Brier skill, bets needed to prove an edge) |
| Backtest | Kelly bankroll path, by-season table, calibration plot, walk-forward coefficients, bet log CSV |
| Early lines & CLV | Does the market later move toward the model? Walk-forward bets at mid-week lines with closing-line value |
| This week | Upcoming games, editable lines/odds from your book, EV, Kelly stakes, log to ledger |
| Ledger | Paper-trade record graded against results and closing lines (CLV) |

## Pipeline

1. **Margin-Elo ratings** (`ratings.py`): points-based, no look-ahead.
2. **Market baseline** (`probability.py`): mean margin implied by line + no-vig odds,
   with learned key-number weights. The market alone gives zero edge.
3. **Trust coefficient** (`model.py`): walk-forward OLS of
   `result - market mean` on `(model - line)` and rest. Fit on prior seasons only.
4. **Bets** (`backtest.py`, `staking.py`): P(cover/push/lose), EV at your odds,
   push-aware fractional Kelly, stake cap.
5. **Testing** (`stats.py`, `tune.py`): ratings tuned on forecast error in training
   seasons; holdout untouched.

## Generic CSV schema

Required: `date, home_team, away_team, home_score, away_score, spread_line`
Optional: `season, home_odds, away_odds, neutral, rest_diff, early_line`

`spread_line` default convention is home perspective with + = home favored.
If yours is the posted home spread (-3.5 = home favored), pick that option in the
sidebar or pass `--sportsbook-lines`. Leave scores blank for upcoming games.

## Adding a feature

Add the column in `data.py`, then add it to `_design()` in `model.py`. The walk-forward
fit, t-stats, and the Verdict tab pick it up automatically. Keep a feature only if its
holdout t-stat holds up.
